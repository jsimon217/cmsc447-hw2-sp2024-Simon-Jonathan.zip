
from flask import Flask
from flask import render_template
from flask import request
import sqlite3

app = Flask(__name__)

# Home Page
@app.route("/")
def home():
    connection = sqlite3.connect('database.db')
    connection.row_factory = sqlite3.Row
    cur = connection.cursor()

    #gets data to load into table
    cur.execute('SELECT * FROM users')
    rows = cur.fetchall()

    connection.close()
    return render_template("home.html", data = rows)

# Route to adda new user
@app.route("/adduser", methods = ['POST', 'GET'])
def adduser():
    if request.method == 'POST':
        try:
            user_name = request.form['username']
            user_id = request.form['id']
            user_score = request.form['score']

            with sqlite3.connect('database.db') as connection:
                cur = connection.cursor()
                #inserts new values into database
                cur.execute("INSERT INTO users (user_name, user_id, user_score) VALUES (?,?,?)",(user_name, user_id, user_score,))

                connection.commit()
        except:
            connection .rollback()

        finally:
            connection.close()
            return render_template('home.html')

# Route used to delete the user of the row its in   
@app.route("/delete", methods=['POST','GET'])
def delete():
    if request.method == 'POST':
        try:
            #gets the id to delete it from the database (if two users have the same id will delete both)
            user_id = request.form['id']
            
            with sqlite3.connect('database.db') as con:
                    cur = con.cursor()
                    cur.execute("DELETE FROM users WHERE user_id="+user_id)
                    con.commit()

        finally:
            con.close()
            # Send the transaction message to result.html
            return render_template('home.html')

if __name__ == "__main__":
    app.run(debug=True)
